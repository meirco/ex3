//
// Created by gil on 24/12/18.
//

#ifndef EX3_ENTERC_H
#define EX3_ENTERC_H


#include "Command.h"

using namespace std;

class EnterC : public Command {
    virtual  int execute(vector<string> vector1);

};


#endif //EX3_ENTERC_H
