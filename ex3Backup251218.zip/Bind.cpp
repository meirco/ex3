//
// Created by gil on 20/12/18.
//

#include "Bind.h"

int Bind::execute(vector<string> vector1) {



}
