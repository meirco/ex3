//
// Created by gil on 20/12/18.
//

#include "If.h"

int If::execute(vector<string> vector1) {
    return 0;
}
