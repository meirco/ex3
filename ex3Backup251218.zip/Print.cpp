//
// Created by gil on 20/12/18.
//

#include <iostream>
#include "Print.h"

using namespace std;

int Print::execute(vector<string> vector1) {

}
