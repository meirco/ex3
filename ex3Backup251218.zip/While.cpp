//
// Created by gil on 20/12/18.
//

#include "While.h"
#include "DataBase.h"

int While::execute(vector<string> vector1) {

    DataBase* dataBase = DataBase::getInstance();


}
