//
// Created by gil on 20/12/18.
//

#include <unistd.h>
#include <iostream>
#include "Sleep.h"

int Sleep::execute(vector<string> vector1) {
    int microSeconds= stoi(vector1.at(1));
    usleep(microSeconds * 1000);
    int count = vector1.size();
    return count;
}
